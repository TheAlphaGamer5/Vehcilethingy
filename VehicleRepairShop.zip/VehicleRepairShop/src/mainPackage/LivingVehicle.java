package mainPackage;

public abstract class LivingVehicle extends Vehicle{

}
