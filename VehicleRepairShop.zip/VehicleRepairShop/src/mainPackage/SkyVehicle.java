package mainPackage;

public abstract class SkyVehicle extends Vehicle{

}
