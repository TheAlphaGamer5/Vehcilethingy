package mainPackage;

public abstract class LandVehicle extends Vehicle{
	
}
